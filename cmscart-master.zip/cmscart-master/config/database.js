module.exports = {
    database: 'mongodb://localhost/cmscart'
}